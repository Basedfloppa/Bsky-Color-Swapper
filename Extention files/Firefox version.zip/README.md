# BlueSky Collor Paller Swapper

A cross browser extention that allows swapping colors on bsky.app for creating personalized color themes.

Link for firefox: https://addons.mozilla.org/en-US/firefox/addon/bluesky-color-pallet-swapper/

There is no link for chrome as i am not able to pay registration fee right now, so here link on how to add this extention manually: https://certera.com/kb/how-to-manually-install-a-chrome-extension-in-2-ways/

If you have any questions or additions you would like me to make, feel free to create issue on github or message me on bsky at [@catinvoid.bsky.social](https://bsky.app/profile/catinvoid.bsky.social)
