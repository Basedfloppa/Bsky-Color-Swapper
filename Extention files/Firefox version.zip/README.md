# BlueSky Color Palette Swapper

A cross browser extension that allows swapping colors on bsky.app for creating personalized color themes.

Link for firefox: https://addons.mozilla.org/firefox/addon/bluesky-color-pallet-swapper/

Link for chrome: https://chromewebstore.google.com/detail/blueskycolorpalletswapper/befmbenmkbhjkkcdngmnfapgfpdiafbe

If you have any questions or additions you would like me to make, feel free to create issue on GitHub or message me on BlueSky at [@catinvoid.bsky.social](https://bsky.app/profile/catinvoid.bsky.social)
